package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.RoleRepository;
import com.project.hrms.dto.RoleDto;
import com.project.hrms.entity.Role;

@Service
public class RoleService {

	@Autowired
	RoleRepository roleRepository;

	public void saveRole(RoleDto roleDto) {
		roleRepository.save(roleDtoToRole(roleDto));
	}

	//fetch data from database by roleId
	public Optional<Role> roleById(int roleId){
		return roleRepository.findById(roleId);
	}

	//fetch all data from database
	public List<RoleDto> getAllRole(){
		List<Role> listRole = this.roleRepository.findAll();
		List<RoleDto> userToList = listRole.stream().map(role -> this.roleToRoleDto(role)).collect(Collectors.toList());
		return userToList;
	}

	//update data from database
	public RoleDto updateRole(RoleDto roleDto) {
		roleRepository.save(roleDtoToRole(roleDto));
		return roleDto;
	}

	//delete data from database
	public void deleteRole(int roleId) {
		roleRepository.deleteById(roleId);
	}

	public Role roleDtoToRole(RoleDto roleDto) {
		Role role = new Role();

		role.setRoleId(roleDto.getRoleId());
		role.setRoleName(roleDto.getRoleName());
		return role;
	}

	public RoleDto roleToRoleDto(Role role) {
		RoleDto roleDto = new RoleDto();

		roleDto.setRoleId(role.getRoleId());
		roleDto.setRoleName(role.getRoleName());
		return roleDto;

	}

}
