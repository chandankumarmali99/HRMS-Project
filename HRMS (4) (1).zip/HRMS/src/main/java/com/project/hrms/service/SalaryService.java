package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.SalaryRepository;
import com.project.hrms.dto.SalaryDto;
import com.project.hrms.entity.Salary;

@Service
public class SalaryService {


	@Autowired
	SalaryRepository salaryRepository;

	public void saveSalary(SalaryDto salaryDto) {
		salaryRepository.save(salaryDtoToSalary(salaryDto));
	}

	//fetch data from database by employeeId
	public Optional<Salary> salaryById(int employeeId){
		return salaryRepository.findById(employeeId);
	}

	//fetch all data from database
	public List<SalaryDto> getAllSalary(){
		List<Salary> listSalary = this.salaryRepository.findAll();
		List<SalaryDto> userToList = listSalary.stream().map(salary -> this.salaryToSalaryDto(salary)).collect(Collectors.toList());
		return userToList;
	}
	
	//update data from database
	public SalaryDto updateSalary(SalaryDto salaryDto) {
		salaryRepository.save(salaryDtoToSalary(salaryDto));
		return salaryDto;
	}
	
	//delete data from database
	public void deleteSalary(int employeeId) {
		salaryRepository.deleteById(employeeId);
	}

	public Salary salaryDtoToSalary(SalaryDto salaryDto) {
		Salary salary = new Salary();
		salary.setEmployeeId(salaryDto.getEmployeeId());
		salary.setSalaryAmount(salaryDto.getSalaryAmount());
		salary.setBonus(salaryDto.getBonus());
		return salary;
	}

	public SalaryDto salaryToSalaryDto(Salary salary) {
		SalaryDto salaryDto = new SalaryDto();
		salaryDto.setEmployeeId(salary.getEmployeeId());
		salaryDto.setSalaryAmount(salary.getSalaryAmount());
		salaryDto.setBonus(salary.getBonus());
		return salaryDto;

	}

}
