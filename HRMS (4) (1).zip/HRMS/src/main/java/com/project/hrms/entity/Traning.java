package com.project.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="traning")
public class Traning {
	
	
	@Id
	private String traningTitle;
	private String traningDesc;
	
	
	public String getTraningTitle() {
		return traningTitle;
	}
	public void setTraningTitle(String traningTitle) {
		this.traningTitle = traningTitle;
	}
	public String getTraningDesc() {
		return traningDesc;
	}
	public void setTraningDesc(String traningDesc) {
		this.traningDesc = traningDesc;
	}
	
	
	@Override
	public String toString() {
		return "Traning [traningTitle=" + traningTitle + ", traningDesc=" + traningDesc + "]";
	}
	
	
	

}
