package com.project.hrms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.TraningDto;
import com.project.hrms.service.TraningService;

@RestController
public class TraningController {


	@Autowired
	TraningService traningService;

	//save data from database
	@PostMapping("/savetraning")
	public ResponseEntity<TraningDto> saveTraning(@RequestBody TraningDto traningDto){
		traningService.saveTraning(traningDto);
		return new ResponseEntity<>(traningDto, HttpStatus.CREATED);
	}

	//fetch data from database by roleId
	@GetMapping("/fetchtraning")
	public ResponseEntity<List<TraningDto>> getTraning(){
		List<TraningDto> allTraning = traningService.getAllTraning();
		ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		return ResponseEntity.of(Optional.of(allTraning));
	}

	//update data from database
	@PutMapping("/updatetraning")
	public ResponseEntity<TraningDto> updateTraning(@RequestBody TraningDto traningDto){
		traningService.updateTraning(traningDto);
		return new ResponseEntity<>(traningDto, HttpStatus.ACCEPTED);
	}

	//delete data from database
	@DeleteMapping("/traning/{traningtitle}")
	public void deleteTraning(@PathVariable("traningTitle")String traningTitle) {
		traningService.traningByTitle(traningTitle);
	}

}
