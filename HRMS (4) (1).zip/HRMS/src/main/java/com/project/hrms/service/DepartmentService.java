package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.DepartmentRepository;
import com.project.hrms.dto.DepartmentDto;
import com.project.hrms.entity.Department;


@Service
public class DepartmentService {
	
	@Autowired
	DepartmentRepository departmentRepository;
	
	public void saveDept(DepartmentDto departmentDto) {
		departmentRepository.save(departmentDtoToDepartment(departmentDto));
	}
	
	// fetch data from database by employeeId
	public Optional<Department> employeeById(int employeeId){
		return departmentRepository.findById(employeeId);
	}
	
	// fetch all data from database
	public List<DepartmentDto> getAllDepartment(){
		List<Department> listDepartment = this.departmentRepository.findAll();
		List<DepartmentDto> userToList = listDepartment.stream().map(department -> this.departmentToDepartmentDto(department)).collect(Collectors.toList());
		return userToList;
	}
	
	// update data from database
	public DepartmentDto updateDepartment(DepartmentDto departmentDto) {
		departmentRepository.save(departmentDtoToDepartment(departmentDto));
		return departmentDto;
	}
	
	//delete data from database
	public void deleteDepartment(int employeeId) {
		departmentRepository.deleteById(employeeId);
	}

	
	public Department departmentDtoToDepartment(DepartmentDto departmentDto) {
		Department department = new Department();
		department.setEmployeeId(departmentDto.getEmployeeId());
		department.setDepartmentTitle(departmentDto.getDepartmentTitle());
		return department;
	}
	
	public DepartmentDto departmentToDepartmentDto(Department department) {
		DepartmentDto departmentDto = new DepartmentDto();
		departmentDto.setEmployeeId(department.getEmployeeId());
		departmentDto.setDepartmentTitle(department.getDepartmentTitle());
		return departmentDto;
		
	}
}
