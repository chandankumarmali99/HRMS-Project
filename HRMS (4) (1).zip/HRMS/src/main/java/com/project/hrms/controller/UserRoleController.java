package com.project.hrms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.UserRoleDto;
import com.project.hrms.service.UserRoleService;

@RestController
public class UserRoleController {


	@Autowired
	UserRoleService userRoleService;

	//save data in database
	@PostMapping("/saveuserRole")
	public ResponseEntity<UserRoleDto> SaveUserRole(@RequestBody UserRoleDto userRoleDto){
		userRoleService.saveUserRole(userRoleDto);
		return new ResponseEntity<>(userRoleDto, HttpStatus.CREATED);
	}

	//fetch data from database by roleId
	@GetMapping("/fetchuserrole")
	public ResponseEntity<List<UserRoleDto>> getUserRole(){
		List<UserRoleDto> allUserRole = userRoleService.getAllUserRole();
		ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		return ResponseEntity.of(Optional.of(allUserRole));
	}

	//update data from database
	@PutMapping("/updateuserrole")
	public ResponseEntity<UserRoleDto> updateUserRole(@RequestBody UserRoleDto userRoleDto){
		userRoleService.updateUserRole(userRoleDto);
		return new ResponseEntity<>(userRoleDto, HttpStatus.ACCEPTED);
	}

	//delete data from database
	@DeleteMapping("/userrole/{roleId}")
	public void deleteRole(@PathVariable("roleId")int id) {
		userRoleService.deleteUserRole(id);
	}
}
