package com.project.hrms.dto;

import javax.persistence.Id;

public class SalaryDto {

	@Id
	private int employeeId;
	private int salaryAmount;
	private String bonus;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getSalaryAmount() {
		return salaryAmount;
	}
	public void setSalaryAmount(int salaryAmount) {
		this.salaryAmount = salaryAmount;
	}
	public String getBonus() {
		return bonus;
	}
	public void setBonus(String bonus) {
		this.bonus = bonus;
	}
	
	
	@Override
	public String toString() {
		return "SalaryDto [employeeId=" + employeeId + ", salaryAmount=" + salaryAmount + ", bonus=" + bonus + "]";
	}
	
	
}
