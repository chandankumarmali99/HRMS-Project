package com.project.hrms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.DepartmentDto;
import com.project.hrms.service.DepartmentService;

@RestController
public class DepartmentController {
	
	
	@Autowired
	DepartmentService departmentService;
	
	//save data in database
	@PostMapping("/savedepartment")
	public ResponseEntity<DepartmentDto> saveDep(@RequestBody DepartmentDto departmentDto){
		departmentService.saveDept(departmentDto);
		return new ResponseEntity<>(departmentDto, HttpStatus.CREATED);
		
	}
	
	//fetch data from database by employeeId
	@GetMapping("/fetchdepartment")
	public ResponseEntity<List<DepartmentDto>> getDepartment(){
		List<DepartmentDto> allDepartment = departmentService.getAllDepartment();
		ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		return ResponseEntity.of(Optional.of(allDepartment));
	}
	
	//update record from database
	@PutMapping("/updatedepartment")
	public ResponseEntity<DepartmentDto> updateDepartment(@RequestBody DepartmentDto departmentDto){
		departmentService.updateDepartment(departmentDto);
		return new ResponseEntity<>(departmentDto, HttpStatus.ACCEPTED);
	}
	
	//delete data from database
	@DeleteMapping("/department/{employeeId}")
	public void deleteDepartment(@PathVariable("employeeId") int id) {
		departmentService.employeeById(id);
	}

}
