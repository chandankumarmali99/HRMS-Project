package com.project.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="department")
public class Department {
	
	
	@Id
	private int employeeId;
	private String departmentTitle;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getDepartmentTitle() {
		return departmentTitle;
	}
	public void setDepartmentTitle(String departmentTitle) {
		this.departmentTitle = departmentTitle;
	}
	
	
	@Override
	public String toString() {
		return "Department [employeeId=" + employeeId + ", departmentTitle=" + departmentTitle + "]";
	}
	
	

}
