package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.AttendanceRepository;
import com.project.hrms.dto.AttendanceDto;
import com.project.hrms.entity.Attendance;


@Service
public class AttendanceService {
	
	
	@Autowired
	AttendanceRepository attendanceRepository;
	
	public void saveAttendance(AttendanceDto attendanceDto) {
		attendanceRepository.save(attendanceDtoToAttendance(attendanceDto));
	}
	
	// fetch data from database by employeeId
	public Optional<Attendance> employeeById(int employeeId){
		return attendanceRepository.findById(employeeId);
	}
	
	// fetch all data from database
	public List<AttendanceDto> getAllAttendance(){
		List<Attendance> listAttendance = this.attendanceRepository.findAll();
		List<AttendanceDto> userToList = listAttendance.stream().map(attendance -> this.attendanceToAttendanceDto(attendance)).collect(Collectors.toList());
		return userToList;
	}
	
	// delete data from database by employeeId
	public void deleteEmployee(int employeeId) {
		attendanceRepository.deleteById(employeeId);
	}
	
	// update data from database
	public AttendanceDto updateAttendance(AttendanceDto attendanceDto) {
		attendanceRepository.save(attendanceDtoToAttendance(attendanceDto));
		return attendanceDto;
	}
	

	public Attendance attendanceDtoToAttendance(AttendanceDto attendanceDto) {
		Attendance attendance = new Attendance();
		attendance.setEmployeeId(attendanceDto.getEmployeeId());
		attendance.setAttendanceType(attendanceDto.getAttendanceType());
		attendance.setAttendanceDateTime(attendanceDto.getAttendanceDateTime());
		return attendance;
	}
	
	public AttendanceDto attendanceToAttendanceDto(Attendance attendance) {
		AttendanceDto attendanceDto = new AttendanceDto();
		attendanceDto.setEmployeeId(attendance.getEmployeeId());
		attendanceDto.setAttendanceType(attendance.getAttendanceType());
		attendanceDto.setAttendanceDateTime(attendance.getAttendanceDateTime());
		return attendanceDto;
		
	}
}
