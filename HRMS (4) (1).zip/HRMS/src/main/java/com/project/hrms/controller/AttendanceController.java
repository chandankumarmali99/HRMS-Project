package com.project.hrms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.AttendanceDto;
import com.project.hrms.service.AttendanceService;

@RestController
public class AttendanceController {
	
	
	@Autowired
	AttendanceService attendanceService;
	
	
	@PostMapping("/saveattendance")
	public ResponseEntity<AttendanceDto> SaveAtten(@RequestBody AttendanceDto attendanceDto){
		attendanceService.saveAttendance(attendanceDto);
		return new ResponseEntity<>(attendanceDto, HttpStatus.CREATED);
	}
	
	// fetch data from database by employeeId
	@GetMapping("/fetchattendance")
	public ResponseEntity<List<AttendanceDto>> getAttendance(){
		List<AttendanceDto> allAttendance = attendanceService.getAllAttendance();
		ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		return ResponseEntity.of(Optional.of(allAttendance));
	}
	
	// update record from database 
	@PutMapping("/updateattendance")
	public ResponseEntity<AttendanceDto> updateAttendance(@RequestBody AttendanceDto attendanceDto){
		attendanceService.updateAttendance(attendanceDto);
		return new ResponseEntity<>(attendanceDto, HttpStatus.ACCEPTED);
	}
	
	// delete data from database
	@DeleteMapping("/employee/{employeeId}")
	public void deleteAttendance(@PathVariable("employeeId")int id) {
		attendanceService.employeeById(id);
	}

}
