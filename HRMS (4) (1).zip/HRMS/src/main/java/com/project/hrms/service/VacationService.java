package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.VacationRepository;
import com.project.hrms.dto.VacationDto;
import com.project.hrms.entity.Vacation;

@Service
public class VacationService {


	@Autowired
	VacationRepository vacationRepository;

	public void saveVacation(VacationDto vacationDto) {
		vacationRepository.save(vacationDtoToVacation(vacationDto));
	}

	//fetch data from database by roleId
	public Optional<Vacation> vacationById(int employeeId){
		return vacationRepository.findById(employeeId);
	}

	//fetch all data from database
	public List<VacationDto> getAllVacation(){
		List<Vacation> listVacation = this.vacationRepository.findAll();
		List<VacationDto> userToList = listVacation.stream().map(vacation -> this.vacationToVacationDto(vacation)).collect(Collectors.toList());
		return userToList;
	}

	//update data from database
	public VacationDto updateVacation(VacationDto vacationDto) {
		vacationRepository.save(vacationDtoToVacation(vacationDto));
		return vacationDto;
	}

	//delete data from database
	public void deleteVacation(int employeeId) {
		vacationRepository.deleteById(employeeId);
	}

	public Vacation vacationDtoToVacation(VacationDto vacationDto) {
		Vacation vacation = new Vacation();

		vacation.setEmployeeId(vacationDto.getEmployeeId());
		vacation.setDateFrom(vacationDto.getDateFrom());
		vacation.setDateTo(vacationDto.getDateTo());
		vacation.setTitle(vacationDto.getTitle());
		return vacation;
	}

	public VacationDto vacationToVacationDto(Vacation vacation) {
		VacationDto vacationDto = new VacationDto();

		vacationDto.setEmployeeId(vacation.getEmployeeId());
		vacationDto.setDateFrom(vacation.getDateFrom());
		vacationDto.setDateTo(vacation.getDateTo());
		vacationDto.setTitle(vacation.getTitle());
		return vacationDto;

	}
}
