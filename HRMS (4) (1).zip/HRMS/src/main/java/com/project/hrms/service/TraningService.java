package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.TraningRepository;
import com.project.hrms.dto.TraningDto;
import com.project.hrms.entity.Traning;

@Service
public class TraningService {


	@Autowired
	TraningRepository traningRepository;

	public void saveTraning(TraningDto traningDto) {
		traningRepository.save(traningDtoToTraning(traningDto));
	}

	//fetch data from database by traningTitle
	public Optional<Traning> traningByTitle(String traningTitle){
		return traningRepository.findById(traningTitle);
	}

	//fetch all data from database
	public List<TraningDto> getAllTraning(){
		List<Traning> listTraning = this.traningRepository.findAll();
		List<TraningDto> userToList = listTraning.stream().map(traning -> this.traningToTraningDto(traning)).collect(Collectors.toList());
		return userToList;
	}

	//update data from database
	public TraningDto updateTraning(TraningDto traningDto) {
		traningRepository.save(traningDtoToTraning(traningDto));
		return traningDto;
	}

	//delete data from database
	public void deleteTraning(Traning traningTitle) {
		traningRepository.delete(traningTitle);
	}


	public Traning traningDtoToTraning(TraningDto traningDto) {
		Traning traning = new Traning();

		traning.setTraningTitle(traningDto.getTraningTitle());
		traning.setTraningDesc(traningDto.getTraningDesc());
		return traning;
	}

	public TraningDto traningToTraningDto(Traning traning) {
		TraningDto traningDto = new TraningDto();

		traningDto.setTraningTitle(traning.getTraningTitle());
		traningDto.setTraningDesc(traning.getTraningDesc());
		return traningDto;

	}

}
