package com.project.hrms.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.project.hrms.entity.Department;


@EnableJpaRepositories
public interface DepartmentRepository extends JpaRepository<Department, Integer>{

}
