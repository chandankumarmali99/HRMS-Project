package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.UserRepository;
import com.project.hrms.dto.UserDto;
import com.project.hrms.entity.User;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public void saveUser(UserDto userDto) {
		userRepository.save(userDtoTouser(userDto));
	}

	//fetch data from database by roleId
	public Optional<User> userById(int userId){
		return userRepository.findById(userId);
	}

	//fetch all data from database
	public List<UserDto> getAllUser(){
		List<User> listUser = this.userRepository.findAll();
		List<UserDto> userToList = listUser.stream().map(user -> this.userToUserDto(user)).collect(Collectors.toList());
		return userToList;
	}

	//update data from database
	public UserDto updateUser(UserDto userDto) {
		userRepository.save(userDtoTouser(userDto));
		return userDto;
	}

	//delete data from database
	public void deleteUser(int userId) {
		userRepository.deleteById(userId);
	}

	public User userDtoTouser(UserDto userDto) {
		User user = new User();

		user.setUserId(userDto.getUserId());
		user.setUserName(userDto.getUserName());
		user.setUserEmail(userDto.getUserEmail());
		user.setUserPassword(userDto.getUserPassword());
		user.setRoles(userDto.getRoles());
		return user;
	}

	public UserDto userToUserDto(User user) {
		UserDto userDto = new UserDto();

		userDto.setUserId(user.getUserId());
		userDto.setUserName(user.getUserName());
		userDto.setUserEmail(user.getUserEmail());
		userDto.setUserPassword(user.getUserPassword());
		userDto.setRoles(user.getRoles());
		return userDto;

	}
}
