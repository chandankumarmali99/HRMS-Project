package com.project.hrms.dto;

import javax.persistence.Id;

public class AttendanceDto {

	@Id
	private int employeeId;
	
	private String attendanceType;
	
	private String attendanceDateTime;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getAttendanceType() {
		return attendanceType;
	}
	public void setAttendanceType(String attendanceType) {
		this.attendanceType = attendanceType;
	}
	public String getAttendanceDateTime() {
		return attendanceDateTime;
	}
	public void setAttendanceDateTime(String attendanceDateTime) {
		this.attendanceDateTime = attendanceDateTime;
	}
	
	
	@Override
	public String toString() {
		return "AttendanceDto [employeeId=" + employeeId + ", attendanceType=" + attendanceType
				+ ", attendanceDateTime=" + attendanceDateTime + "]";
	}
	
	
}
