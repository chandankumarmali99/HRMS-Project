package com.project.hrms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.VacationDto;
import com.project.hrms.service.VacationService;

@RestController
public class VacationController {


	@Autowired
	VacationService vacationService;

	//save data in database
	@PostMapping("/savevacation")
	public ResponseEntity<VacationDto> SaveVacation(@RequestBody VacationDto vacationDto){
		vacationService.saveVacation(vacationDto);
		return new ResponseEntity<>(vacationDto, HttpStatus.CREATED);

	}

	//fetch data from database by roleId
	@GetMapping("/fetchvacation")
	public ResponseEntity<List<VacationDto>> getVacation(){
		List<VacationDto> allVacation = vacationService.getAllVacation();
		ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		return ResponseEntity.of(Optional.of(allVacation));
	}

	//update data from database
	@PutMapping("/updatevacation")
	public ResponseEntity<VacationDto> updateVacation(@RequestBody VacationDto vacationDto){
		vacationService.updateVacation(vacationDto);
		return new ResponseEntity<>(vacationDto, HttpStatus.ACCEPTED);
	}

	//delete data from database
	@DeleteMapping("/vacation/{employeeId}")
	public void deleteVacation(@PathVariable("employeeId")int id) {
		vacationService.deleteVacation(id);
	}
}
