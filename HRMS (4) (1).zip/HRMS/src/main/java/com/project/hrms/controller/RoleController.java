package com.project.hrms.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.RoleDto;
import com.project.hrms.service.RoleService;

@RestController
public class RoleController {
	
	
	@Autowired
	RoleService roleService;
	
	//save data in database
	@PostMapping("/saverole")
	public ResponseEntity<RoleDto> SaveRole(@RequestBody RoleDto roleDto){
		roleService.saveRole(roleDto);
		return new ResponseEntity<>(roleDto, HttpStatus.CREATED);
		
	}
	
	//fetch data from database by roleId
	@GetMapping("/fetchrole")
	public ResponseEntity<List<RoleDto>> getRole(){
		List<RoleDto> allRole = roleService.getAllRole();
		ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		return ResponseEntity.of(Optional.of(allRole));
	}
	
	//update data from database
	@PutMapping("/updaterole")
	public ResponseEntity<RoleDto> updateRole(@RequestBody RoleDto roleDto){
		roleService.updateRole(roleDto);
		return new ResponseEntity<>(roleDto, HttpStatus.ACCEPTED);
	}
	
	//delete data from database
	@DeleteMapping("/role/{roleId}")
	public void deleteRole(@PathVariable("roleId")int id) {
		roleService.roleById(id);
	}

}
