package com.project.hrms.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.EmployeeRepository;
import com.project.hrms.dto.EmployeeDto;
import com.project.hrms.entity.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;

	//save data in database
	public void saveEmployee(EmployeeDto employeeDto) {
		employeeRepository.save(employeeDtoToEmployee(employeeDto));
	}

	// fetch data from database by employeeId
	public Optional<Employee> employeeById(int employeeId){
		return employeeRepository.findById(employeeId);
	}

	//fetch data from database by employeeId
	public List<EmployeeDto> getAllEmployee(){
		List<Employee> listEmployee = this.employeeRepository.findAll();
		List<EmployeeDto> userToList = listEmployee.stream().map(employee -> this.employeeToEmployeeDto(employee)).collect(Collectors.toList());
		return userToList;
	}

	//update data from database
	public EmployeeDto updateEmployee(EmployeeDto employeeDto) {
		employeeRepository.save(employeeDtoToEmployee(employeeDto));
		return employeeDto;
	}

	//delete data from database
	public void deleteEmployee(int employeeId) {
		employeeRepository.deleteById(employeeId);
	}


	public Employee employeeDtoToEmployee(EmployeeDto employeeDto) {
		Employee employee = new Employee();
		employee.setEmployeeId(employeeDto.getEmployeeId());
		employee.setEmployeeName(employeeDto.getEmployeeAddress());
		employee.setEmployeeEmail(employeeDto.getEmployeeEmail());
		employee.setEmployeePhone(employeeDto.getEmployeePhone());
		employee.setEmployeeAddress(employeeDto.getEmployeeAddress());
		employee.setEmployeePassword(employeeDto.getEmployeePassword());
		return employee;
	}

	public EmployeeDto employeeToEmployeeDto(Employee employee) {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(employee.getEmployeeId());
		employeeDto.setEmployeeName(employee.getEmployeeName());
		employeeDto.setEmployeeEmail(employee.getEmployeeEmail());
		employeeDto.setEmployeePhone(employee.getEmployeePhone());
		employeeDto.setEmployeeAddress(employee.getEmployeeAddress());
		employeeDto.setEmployeePassword(employee.getEmployeePassword());
		return employeeDto;

	}
}
